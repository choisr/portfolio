<?
	$db = new mysqli("localhost", "zxchsr", "tnrfks1202", "zxchsr"); 
	$db ->set_charset("utf8"); 
?>