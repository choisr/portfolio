<?php
	define("_web_url_" ,"http://zxchsr.dothome.co.kr/board" );
	define("_web_image_path_" ,"http://zxchsr.dothome.co.kr/board/img" );
?>
